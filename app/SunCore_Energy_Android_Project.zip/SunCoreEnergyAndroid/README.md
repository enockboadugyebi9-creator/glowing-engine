# SunCore Energy Android app (starter v1.0)

This is a build-ready Android Studio project for a first demo of SunCore Energy.

## Included
- Android WebView shell with a locally bundled app interface
- Home, product catalogue, demo cart, installation request form, account placeholder
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact

## Important limitations
- Product listings and prices are sample data, not live inventory or approved prices.
- Cart and installation requests are stored locally on the device only.
- No real customer accounts, database connection, online orders, payment processing, or admin dashboard are active yet.
- Connect Supabase and configure Row Level Security before collecting real customer data.

## Build the APK
Open this folder in Android Studio and run the `app` configuration, or push the project to a GitHub repository. The included GitHub Actions workflow builds `app-debug.apk`; download it from the workflow run's Artifacts section.

Package: `com.suncore.energy`
Version: `1.0.0`
